#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
double rcpp_exact_beta(double a1, double b1, double a2, double b2) {
  
  double prob = 0;
  
  // Saves doing a beta calc each loop
  double x = R::beta(a1,b1);
  
  for (int i = 0; i<=(a2-1); i++){
    
    //double y = R::beta(i+1,b2)
    
    prob = prob + R::beta(a1 + i, b1 + b2)/((b2 + i)*(R::beta(i+1,b2)*x));
    
    //Rcout << prob;
    
  }
  
  
  return prob;
}

// [[Rcpp::export]]
double rcpp_exact_beta_3_arm(double a1, double b1, double a2, double b2, double a3, double b3) {
  
  double big_sum = 0;
  
  for (int i = 0; i <= (a2 - 1); i++) {
    for (int j = 0; j <= (a3 - 1); j++){
      
      big_sum = big_sum + R::beta(i + j + a1, b1 + b2 + b3)/((b2 + i)*R::beta(1+i,b2)*(b3+j)*R::beta(1+j,b3)*R::beta(a1,b1));
      
    }
  }
  
  double prob = 1 - (1 - rcpp_exact_beta(a2,b2,a1,b1)) - (1 -rcpp_exact_beta(a3,b3,a1,b1)) + big_sum;
  
  
  return prob;
}

// [[Rcpp::export]]
double rcpp_exact_beta_4_arm(double a1, double b1, double a2, double b2, double a3, double b3, double a4, double b4) {
  
  double big_sum = 0;
  
  for (int i = 0; i <= (a2 - 1); i++){
    for (int j = 0; j <= (a3 - 1); j++){
      for (int k = 0; k <= (a4 - 1); k++){
        
        big_sum = big_sum + std::exp(R::lbeta(a1+i+j+k, b1+b2+b3+b4)
                                       - std::log(b2+i) - std::log(b3+j) - std::log(b4+k)
                                       - R::lbeta(1+i, b2) - R::lbeta(1+j, b3) - R::lbeta(1+k, b4)
                                       - R::lbeta(a1, b1));
                                       
                                       
      }
    }
  }
  
  
  double prob = 1 - (1 - rcpp_exact_beta(a1,b1,a2,b2)) - (1 - rcpp_exact_beta(a1,b1,a3,b3)) - (1 - rcpp_exact_beta(a1,b1,a4,b4)) + rcpp_exact_beta_3_arm(a1,b1,a2,b2,a3,b3) + rcpp_exact_beta_3_arm(a1,b1,a2,b2,a4,b4) + rcpp_exact_beta_3_arm(a1,b1,a4,b4,a3,b3) - big_sum;
  
  return prob;
}

